The database connection for this program requires CPS_DB.ini which should be placed in C:\Windows on the computer where this program is going to run.
